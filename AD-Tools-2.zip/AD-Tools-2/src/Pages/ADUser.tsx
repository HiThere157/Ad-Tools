import { useSessionStorage } from "../Hooks/useStorage";

export default function ADUserPage({ id }: TabProps) {
  const [data, setData] = useSessionStorage<TabData<AdQuery>>(`tabdata_${id}`, {});

  return <div></div>
}
