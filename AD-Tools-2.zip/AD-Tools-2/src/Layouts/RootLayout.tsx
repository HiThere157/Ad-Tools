import { useState } from "react";
import { useParams } from "react-router";
import Header from "../Components/Header";
import Navbar from "../Components/Navbar";
import ADUserPage from "../Pages/ADUser";

export default function RootLayout() {
  const { tabId } = useParams();
  const [tabs, setTabs] = useState<TabInformation[]>([]);

  const createNewTab = (type: TabType) => {
    setTabs([...tabs, { id: tabs.length.toString(), type }]);
  };

  return (
    <main
      style={{
        gridTemplateAreas: `"header" "navbar" "content"`,
      }}
      className="grid grid-rows-[auto_auto_1fr] h-screen min-w-fit dark:text-whiteColor dark:bg-darkBg"
    >
      <Header />
      <Navbar tabs={tabs} />

      <div style={{ gridArea: "content" }} className="px-4 py-2 overflow-auto">
        <button
          onClick={() => {
            createNewTab("ADUser");
          }}
        >
          ttt
        </button>
      </div>
    </main>
  );
}
