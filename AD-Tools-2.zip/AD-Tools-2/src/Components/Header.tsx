import WinControl from "./WinBar/WinControl";

export default function Header() {
  return (
    <div
      style={{ gridArea: "header" }}
      className="winbar-drag-region select-none flex justify-between border-b-2 dark:bg-lightBg dark:border-elFlatBorder"
    >
      <div className="flex items-center">
        <img src="./icon.svg" alt="AD Tools Logo" className="mx-[1.1rem] h-6" />
        <div className="flex gap-x-3 items-center mt-0.5 whitespace-nowrap">
          <span className="font-bold text-xl">AD Tools</span>
          <span className="dark:text-whiteColorAccent">/</span>
        </div>
      </div>

      <div className="winbar-no-drag flex gap-x-2">
        <WinControl />
      </div>
    </div>
  );
}
