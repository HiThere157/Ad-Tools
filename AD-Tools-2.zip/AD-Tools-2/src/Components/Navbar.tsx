import { NavLink } from "react-router-dom";

type NavbarProps = {
  tabs: TabInformation[];
};
export default function Navbar({ tabs }: NavbarProps) {
  return (
    <nav style={{ gridArea: "navbar" }} className="flex">
      {tabs.map((tab) => {
        return <TabItem key={tab.id} id={tab.id} type={tab.type}/>;
      })}
    </nav>
  );
}

type TabItemProps = {
  id: string;
  type: TabType;
};
function TabItem({ id, type }: TabItemProps) {
  return <NavLink to={`/tab/${id}`}>{type}</NavLink>;
}
