import WinButton from "./WinButton";

import { BsDashLg, BsSquare, BsXLg } from "react-icons/bs";

export default function WinControl() {
  return (
    <div className="winbar-no-drag flex">
      <WinButton onClick={() => {}}>
        <BsDashLg />
      </WinButton>
      <WinButton onClick={() => {}}>
        <BsSquare />
      </WinButton>
      <WinButton onClick={() => {}}>
        <BsXLg />
      </WinButton>
    </div>
  );
}
