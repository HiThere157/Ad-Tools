type Result = {
  output?: { [key: string]: any };
  error?: string;
};

type AdQuery = {
  input?: string;
  domain?: string;
};
type AadQuery = {
  input?: string;
};
type DnsQuery = {
  input?: string;
  type?: string;
};
