type TabInformation = {
  id: string;
  type: TabType;
}

type TabType =
  | "ADSearch"
  | "ADUser"
  | "ADGroup"
  | "ADComputer"
  | "AADSearch"
  | "AADUser"
  | "AADGroup"
  | "AADDevice";

type TabProps = {
  id: string;
};

type TabData<Query> = {
  isLoading: boolean;
  executeOnLoad: boolean;
  query: Query;
  resultData: Result[];
};
