![Lint](https://github.com/HiThere157/Ad-Tools/actions/workflows/lint.yaml/badge.svg)
![CodeQL](https://github.com/HiThere157/Ad-Tools/actions/workflows/codeql.yml/badge.svg)
![Publish](https://github.com/HiThere157/Ad-Tools/actions/workflows/publish.yaml/badge.svg)

[![GitHub release](https://img.shields.io/github/release/HiThere157/Ad-Tools)](https://GitHub.com/HiThere157/Ad-Tools/releases/)
[![Github all releases](https://img.shields.io/github/downloads/HiThere157/Ad-Tools/total.svg)](https://GitHub.com/HiThere157/Ad-Tools/releases/)
